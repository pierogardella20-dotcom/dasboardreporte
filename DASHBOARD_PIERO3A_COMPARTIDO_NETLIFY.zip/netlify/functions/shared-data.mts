import type { Context, Config } from "@netlify/functions";
import { getDeployStore, getStore } from "@netlify/blobs";

const STORE_NAME = "piero3a-dashboard-data";
const DATA_KEY = "latest";
const META_KEY = "meta";

function getDashboardStore(context: Context) {
  const isProduction = context.deploy?.context === "production";
  return isProduction
    ? getStore(STORE_NAME, { consistency: "strong" })
    : getDeployStore(STORE_NAME);
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}

export default async (req: Request, context: Context) => {
  const store = getDashboardStore(context);
  const url = new URL(req.url);

  if (req.method === "GET") {
    if (url.searchParams.get("meta") === "1") {
      const meta = await store.get(META_KEY, { type: "json" });
      return json(meta ?? { exists: false });
    }

    const latest = await store.get(DATA_KEY, { type: "json" });
    if (!latest) return json({ exists: false }, 404);
    return json(latest);
  }

  if (req.method === "POST") {
    const expectedKey = Netlify.env.get("DASHBOARD_ADMIN_KEY");
    const suppliedKey = req.headers.get("x-dashboard-key") ?? "";

    if (!expectedKey) {
      return json({ error: "DASHBOARD_ADMIN_KEY no está configurada en Netlify." }, 500);
    }

    if (suppliedKey !== expectedKey) {
      return json({ error: "Clave de publicación incorrecta." }, 401);
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return json({ error: "El cuerpo enviado no es JSON válido." }, 400);
    }

    if (!Array.isArray(body?.data)) {
      return json({ error: "Falta el arreglo data." }, 400);
    }

    const updatedAt = new Date().toISOString();
    const version = `${Date.now()}-${body.data.length}-${Array.isArray(body.stockGlobal) ? body.stockGlobal.length : 0}`;

    const saved = {
      exists: true,
      version,
      updatedAt,
      source: String(body.source || "Excel"),
      data: body.data,
      stockGlobal: Array.isArray(body.stockGlobal) ? body.stockGlobal : [],
      asnData: Array.isArray(body.asnData) ? body.asnData : [],
    };

    const meta = {
      exists: true,
      version,
      updatedAt,
      rows: saved.data.length,
      stockRows: saved.stockGlobal.length,
      source: saved.source,
    };

    await store.setJSON(DATA_KEY, saved);
    await store.setJSON(META_KEY, meta);

    return json(meta);
  }

  return json({ error: "Método no permitido." }, 405);
};

export const config: Config = {
  path: "/api/shared-data",
};
