DASHBOARD_PIERO3A - DATOS COMPARTIDOS

Archivos:
- public/index.html
- netlify/functions/shared-data.mts
- netlify.toml
- package.json

Funcionamiento:
1. El administrador carga el Excel en el dashboard.
2. El dashboard publica DATA, STOCK GLOBAL y ASN en Netlify Blobs.
3. Todos los usuarios consultan una metadata cada 20 segundos.
4. Cuando hay una versión nueva, descargan automáticamente los datos nuevos.
5. Solo quien conozca DASHBOARD_ADMIN_KEY puede publicar.

IMPORTANTE:
- No pongas la clave en GitHub.
- La variable DASHBOARD_ADMIN_KEY debe estar configurada en Netlify.
